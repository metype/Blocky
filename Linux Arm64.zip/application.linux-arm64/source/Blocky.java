import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import g4p_controls.*; 
import java.awt.Font; 
import java.awt.GraphicsEnvironment; 
import java.awt.GraphicsDevice; 
import java.awt.HeadlessException; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Blocky extends PApplet {






GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
GraphicsDevice[] devices = env.getScreenDevices();
int numberofScreens = devices.length;
Console console;
int mode = 0;
GButton Random;
GButton Controls;
GButton Start;
GButton Back;
GButton Difficulty;
GButton LevelWrap;
GButton Quit;
GButton Info;
GButton ScreenNum;
GButton Options;
GButton Cheats;
GButton Possible;
PImage icon;
float version = 0.7f;
int[][] level;
String command = "";
int scale=45, sx=0, sy=0, x, y, ex, ey, difficulty=1, commandsIndex=0;
int dir=0;
boolean levelWrap=true;
long score=0;
boolean consoleShown=false;
boolean noclip=false, debug=false, allowCheats=false, check_possible=true;
ArrayList<String> commandslist = new ArrayList();
int tenmousex;
int tenmousey;
String[] settings;
boolean newVersionAvailable=false;

public void settings() {
  settings = loadStrings("settings.txt");
  String[] versionS = loadStrings("https://raw.githubusercontent.com/metype/Blocky/master/version.txt");
  if(versionS!=null){
   if(Float.parseFloat(versionS[0])>version){
     newVersionAvailable=true;
   }
  }
  if (settings.length<3) {
    settings=new String[3];
    settings[0]="screen=1";
    settings[1]="cheats=false";
    settings[2]="check_possible=true";
    saveStrings("data/settings.txt", settings);
  }
  String[] teb = settings[0].split("=");
  fullScreen(Integer.parseInt(teb[1]));
  //size(1280,720);
}

public void setup() {
  icon=loadImage("icon.png");
  surface.setIcon(icon);
  level = new int[width/scale][height/scale];
  //txf = new GTextField(this, 10, 10, 280, 46);
  // txf.setFont(new Font("Dialog", Font.PLAIN, 24));
  // txf.setText("Random");
  Random=new GButton(this, width/2-150, 250, 300, 75, "Random");
  Random.setFont(new Font("Dialog", Font.PLAIN, 34));
  Controls=new GButton(this, width/2-150, 350, 300, 75, "Controls");
  Controls.setFont(new Font("Dialog", Font.PLAIN, 34));
  Info=new GButton(this, width/2-150, 450, 300, 75, "Information");
  Info.setFont(new Font("Dialog", Font.PLAIN, 34));
  Quit=new GButton(this, width/2-150, 650, 300, 75, "Quit");
  Quit.setFont(new Font("Dialog", Font.PLAIN, 34));
  Back=new GButton(this, width/2-150, 600, 300, 75, "Back");
  Back.setFont(new Font("Dialog", Font.PLAIN, 34));
  Back.setVisible(false);
  Start=new GButton(this, width/2-150, 500, 300, 75, "Start");
  Start.setFont(new Font("Dialog", Font.PLAIN, 34));
  Start.setVisible(false);
  Difficulty=new GButton(this, width/2-300, 200, 250, 75, "Difficulty:1");
  Difficulty.setFont(new Font("Dialog", Font.PLAIN, 34));
  Difficulty.setVisible(false);
  LevelWrap=new GButton(this, width/2+50, 200, 250, 75, "Level Wrapping:true");
  LevelWrap.setFont(new Font("Dialog", Font.PLAIN, 30));
  LevelWrap.setVisible(false);
  settings = loadStrings("settings.txt");
  String[] teb = settings[0].split("=");
  ScreenNum=new GButton(this, width/2-150, 200, 300, 75, "Default Screen:"+teb[1]);
  ScreenNum.setFont(new Font("Dialog", Font.PLAIN, 34));
  ScreenNum.setVisible(false);
  Cheats=new GButton(this, width/2-150, 300, 300, 75, "Cheats:"+settings[1].split("=")[1]);
  Cheats.setFont(new Font("Dialog", Font.PLAIN, 34));
  Cheats.setVisible(false);
  allowCheats=Boolean.parseBoolean(settings[1].split("=")[1]);
  check_possible=Boolean.parseBoolean(settings[2].split("=")[1]);
  Options=new GButton(this, width/2-150, 550, 300, 75, "Options");
  Options.setFont(new Font("Dialog", Font.PLAIN, 34));
  Options.setVisible(true);
  console=new Console(0, 0, width, 500);
  surface.setTitle("Blocky - A Puzzle Game v"+version);
}

public void draw() {
  try {
    background(51);

    textAlign(CENTER, CENTER);
    textSize(30);
    switch(mode) {
      case(0):
      cursor();
      score=0;
      text("Blocky - A Puzzle Game", width/2, 50);
              textSize(15);
              text("Version : "+version,width/2,80);
      if(newVersionAvailable){
        text("New Version Available!, get it at:https://github.com/metype/Blocky/tree/master",width/2,110);
      }
      Back.setVisible(false);
      Start.setVisible(false);
      Difficulty.setVisible(false);
      Controls.setVisible(true);
      Random.setVisible(true);
      LevelWrap.setVisible(false);
      Quit.setVisible(true);
      Info.setVisible(true);
      Options.setVisible(true);
      ScreenNum.setVisible(false);
      Cheats.setVisible(false);
      break;
      case(5):
      textAlign(LEFT);
      textSize(15);
      text("Changing this will require a restart\n to take effect", width/2+160, 230);
      Back.setVisible(true);
      Start.setVisible(false);
      Difficulty.setVisible(false);
      Controls.setVisible(false);
      Random.setVisible(false);
      LevelWrap.setVisible(false);
      Quit.setVisible(false);
      Info.setVisible(false);
      Options.setVisible(false);
      ScreenNum.setVisible(true);
      Cheats.setVisible(true);
      break;
      case(1):
      float xoff=(width-(level.length*scale))/2;
      float yoff=(height-(level[0].length*scale))/2;
      if (frameCount%25==0) {
        if (tenmousex==mouseX&&tenmousey==mouseY) {
          noCursor();
        } else {
          cursor();
        }
        tenmousex=mouseX;
        tenmousey=mouseY;
      }
      if (tenmousex!=mouseX||tenmousey!=mouseY||mousePressed) {
        cursor();
        if (mousePressed) {
          tenmousex=0;
          tenmousey=0;
        }
      }
      stroke(0);
      boolean end=false;
      boolean start=false;
      for (int i=0; i<level.length; i++) {
        for (int j=0; j<level[i].length; j++) {
          if (level[i][j]==1) {
            fill(0);
          }
          if (level[i][j]==0||level[i][j]>=4) {
            fill(51);
          }
          if (level[i][j]==2) {
            fill(0, 200, 0);
            start=true;
          }
          if (level[i][j]==3) {
            fill(200, 0, 0);
            end=true;
          }
          square((i*scale)+xoff, (j*scale)+yoff, scale);
        }
      }
      if (!start||!end) {
        reset();
        break;
      }
      fill(0, 200, 0);
      stroke(0);
      if (!noclip) {
        switch(dir) {
          case(1):
          if (level[x/scale][constrain((y-1)/scale, 0, (height/scale)-1)]!=1) {
            y-=scale;
          } else {
            //y+=scale;
            dir=0;
          }
          if (level[x/scale][constrain((y-1)/scale, 0, (height/scale)-1)]!=1) {
          } else {
            //y+=scale;
            dir=0;
          }
          break;
          case(2):
          if (level[x/scale][constrain((y+1)/scale, 0, (height/scale)-1)]!=1) {
            y+=scale;
          } else {
            y-=scale;
            dir=0;
          }
          if (level[x/scale][constrain((y+1)/scale, 0, (height/scale)-1)]!=1) {
          } else {
            y-=scale;
            dir=0;
          }
          break;
          case(4):
          if (level[constrain((x+1)/scale, 0, (width/scale)-1)][constrain((y)/scale, 0, (height/scale)-1)]!=1) {
            x+=scale;
          } else {
            x-=scale;
            dir=0;
          }
          if (level[constrain((x+1)/scale, 0, (width/scale)-1)][constrain((y)/scale, 0, (height/scale)-1)]!=1) {
          } else {
            x-=scale;
            dir=0;
          }
          break;
          case(3):
          if (level[constrain((x-1)/scale, 0, (width/scale)-1)][constrain((y)/scale, 0, (height/scale)-1)]!=1) {
            x-=scale;
          } else {
            dir=0;
          }
          if (level[constrain((x-1)/scale, 0, (width/scale)-1)][constrain((y)/scale, 0, (height/scale)-1)]!=1) {
          } else {
            //y+=scale;
            dir=0;
          }
          break;
        }
        edges();
      } else {
        switch(dir) {
          case(1):
          y-=scale;
          dir=0;
          break;
          case(2):
          y+=scale;
          dir=0;
          break;
          case(3):
          x-=scale;
          dir=0;
          break;
          case(4):
          x+=scale;
          dir=0;
        }
      }
      x=(constrain((int)x/scale, 0, (width/scale)-1))*scale;
      y=(constrain((int)y/scale, 0, (height/scale)-1))*scale;
      x=constrain(x, 0, width);
      y=constrain(y, 0, height);
      square(constrain(x+4, 0, width)+xoff, constrain(y+4, 0, height)+yoff, scale-8);
      if (x==ex&&y==ey) {
        reset();
        score++;
        dir=0;
      }
      Difficulty.setVisible(false);
      Controls.setVisible(false);
      Random.setVisible(false);
      Start.setVisible(false);
      Back.setVisible(false);
      LevelWrap.setVisible(false);
      Quit.setVisible(false);
      Info.setVisible(false);
      fill(255);
      textSize(20);
      textAlign(LEFT);
      text("Score : " + score, 2, 20);
      textAlign(RIGHT);
      if (debug) {
        fill(51, 200);
        stroke(0, 200);
        String temp="Blocky Vanilla v"+version+"\nDifficulty:"+difficulty+"\nX:"+x+"\nY:"+y+"\nStart X:"+sx+"\nStart Y:"+sy+"\nEnd X:"+ex+"\nEnd Y:"+ey+"\nCheats:"+allowCheats+"\nDefault Screen:"+settings[0].split("=")[1]+"\nFPS:"+floor(frameRate);
        rect(width-textWidth(temp)-15, -10, width, 345);
        fill(255);
        text(temp, width-10, 20);
        textAlign(LEFT);
      }
      break;
      case(2):
      cursor();
      if(allowCheats){
              text("Controls:\n\n\nWASD- Move in the respective direction\nR-Reset map\nE-Reset player's position\nESC-Exits current screen\n`-Toggle console", width/2, (height/2)-100);
      }else{
      text("Controls:\n\n\nWASD- Move in the respective direction\nR-Reset map\nE-Reset player's position\nESC-Exits current screen", width/2, (height/2)-100);
      }
      Controls.setVisible(false);
      Random.setVisible(false);
      Back.setVisible(true);
      Difficulty.setVisible(false);
      LevelWrap.setVisible(false);
      Quit.setVisible(false);
      Info.setVisible(false);
      Options.setVisible(false);
      break;
      case(3):
      cursor();
      text("Information:\n\n\nWhen it looks like the map is resetting multiple times per one reset,\n what's actually happening is that the map generated doesn't have a start, end, or both.\n══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════\nYou start at the green tile and finish at the red.\n══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════\nThe game started in October 2018, and it still being worked on today!", width/2, (height/2)-100);
      Controls.setVisible(false);
      Random.setVisible(false);
      Back.setVisible(true);
      Difficulty.setVisible(false);
      LevelWrap.setVisible(false);
      Quit.setVisible(false);
      Info.setVisible(false);
      Options.setVisible(false);
      break;
      case(4):
      cursor();
      Controls.setVisible(false);
      Random.setVisible(false);
      Start.setVisible(true);
      Back.setVisible(true);
      Difficulty.setVisible(true);
      LevelWrap.setVisible(true);
      Quit.setVisible(false);
      Info.setVisible(false);
      Options.setVisible(false);
    }
    if (!allowCheats) {
      consoleShown=false;
    }
    if (consoleShown) {
      if (mode!=1) {
        consoleShown=false;
      } else {
        console.render();
        fill(255);
        stroke(255);
        if (frameCount%50<25) {
          text(">"+command+"|", 20, console.x+console.height-3);
        } else {
          text(">"+command, 20, console.x+console.height-3);
        }
      }
    }
  }
  catch (Exception e) {
    console.println(e+"");
  }
}

public void handleButtonEvents(GButton button, GEvent event) {
  try {
    if (button == Random) {
      mode=4;
    }
    if (button == Controls) {
      mode=2;
    }
    if (button == Start) {
      mode=1;
      switch(difficulty) {
        case(1):
        scale=75;
        break;
        case(2):
        scale=60;
        break;
        case(3):
        scale=45;
        break;
        case(4):
        scale=35;
        break;
        case(5):
        scale=20;
      }
      level = new int[width/scale][height/scale];
      reset();
    }
    if (button==Quit&&mode==0) {
      exit();
    }
    if (button==Back) {
      mode=0;
    }
    if (button==Difficulty) {
      difficulty=(difficulty==5)?1:difficulty+1;
      Difficulty.setText("Difficulty:"+difficulty);
    }
    if (button==LevelWrap) {
      levelWrap=!levelWrap;
      LevelWrap.setText("Level Wrapping:"+levelWrap);
    }
    if (button==Info) {
      mode=3;
    }
    if (button==Options) {
      mode=5;
    }
    if (button==ScreenNum) {
      settings = loadStrings("settings.txt");
      String[] teb = settings[0].split("=");
      int val = Integer.parseInt(teb[1]);
      val=(val>=numberofScreens)?1:val+1;
      settings[0]="screen="+val;
      ScreenNum.setText("Default Screen:"+val);
      saveStrings("data/settings.txt", settings);
    }
    if (button==Cheats) {
      settings = loadStrings("settings.txt");
      String[] teb = settings[1].split("=");
      boolean val = Boolean.parseBoolean(teb[1]);
      val=!val;
      allowCheats=val;
      settings[1]="cheats="+val;
      Cheats.setText("Cheats:"+val);
      saveStrings("data/settings.txt", settings);
    }
    if (button==Possible) {
      settings = loadStrings("settings.txt");
      String[] teb = settings[2].split("=");
      boolean val = Boolean.parseBoolean(teb[1]);
      val=!val;
      check_possible=val;
      settings[2]="check_possible="+val;
      Possible.setText("Check Possible:"+val);
      saveStrings("data/settings.txt", settings);
    }
  }
  catch (Exception e) {
    console.println(e+"");
  }
}

public void keyPressed() {
  try {
    if (key!=BACKSPACE) {
      command+=key;
    } else {
      command = command.substring(0, (command.length()-1>-1)?command.length()-1:0);
    }
    if (!consoleShown) {
      switch(key) {
        case('r'):
        dir=0;
        reset();
        break;
        case('R'):
        reset();
        dir=0;
        break;
        case('w'):
        if (dir==0) {
          dir=1;
        }
        break;
        case('s'):
        if (dir==0) {
          dir=2;
        }
        break;
        case('a'):
        if (dir==0) {
          dir=3;
        }
        break;
        case('d'):
        if (dir==0) {
          dir=4;
        }
        break;
        case('W'):
        if (dir==0) {
          dir=1;
        }
        break;
        case('S'):
        if (dir==0) {
          dir=2;
        }
        break;
        case('A'):
        if (dir==0) {
          dir=3;
        }
        break;
        case('D'):
        if (dir==0) {
          dir=4;
        }
        break;
        case('e'):
        dir=0;
        x=sx;
        y=sy;
        break;
        case('E'):
        dir=0;
        x=sx;
        y=sy;
        break;
        case('`'):
        consoleShown=!consoleShown;
        command="";
        break;
        case(ESC):
        key=' ';
        if (mode==1) {
          handleOptionDialog(1);
        } else if (mode==0) {
          handleOptionDialog(2);
        } else {
          mode=0;
        }
        break;
      }
    } else {
      switch(key) {
        case(ENTER):
        commandslist.add(command);
        console.println(">"+command);
        eval(command);
        command="";
        break;
        case('`'):
        consoleShown=!consoleShown;
        command="";
        break;
        case(ESC):
        consoleShown=!consoleShown;
        command="";
        key=' ';
        break;
      }
      switch(keyCode) {
        case(38)://up
        commandsIndex=(commandsIndex>0)?commandsIndex-1:0;
        command=commandslist.get(commandsIndex).substring(0, commandslist.get(commandsIndex).length()-1);
        break;
        case(40)://down
        commandsIndex=(commandsIndex<commandslist.size()-1)?commandsIndex+1:commandslist.size()-1;
        command=commandslist.get(commandsIndex).substring(0, commandslist.get(commandsIndex).length()-1);
        break;
      default:
        commandsIndex=commandslist.size();
      }
    }
  }
  catch (Exception e) {
    console.println(e+"");
  }
}

public void edges() {
  try {
    if (levelWrap) {
      if (x>width-scale&&dir==4) {
        x=0;
        dir=4;
        if (level[0][y/scale]==1) {
          x=width;
          dir=0;
        }
      }
      if (x<0&&dir==3) {
        x=width;
        dir=3;
        if (level[level.length-1][y/scale]==1) {
          x=0;
          dir=0;
        }
      }
      if (y<0&&dir==1) {
        y=height;
        dir=1;
        if (level[x/scale][level[x/scale].length-1]==1) {
          y=0;
          dir=0;
        }
      }
      if (y>height-scale&&dir==2) {
        y=-scale;
        dir=2;
        if (level[x/scale][0]==1) {
          y=height;
          dir=0;
        }
      }
    } else {
      dir=(x<0||y<0||y>height||x>width)?0:dir;
      x=(x<0)?0:x; 
      x=(x>width)?width:x; 
      y=(y>height)?height:y; 
      y=(y<0)?0:y;
    }
  }
  catch (Exception e) {
    console.println(e+"");
  }
}

public void handleOptionDialog(int num) {
  try {
    if (num==1) {
      int reply = G4P.selectOption(this, "Are you sure you want to return to title screen?", "Warning", G4P.WARNING, G4P.YES_NO);
      switch(reply) {
      case G4P.OK: 
        mode=0;
        break;
      case G4P.NO:
      }
    } else if (num==2) {
      int reply = G4P.selectOption(this, "Are you sure you want to quit the game?", "Warning", G4P.WARNING, G4P.YES_NO);
      switch(reply) {
      case G4P.OK: 
        exit();
        break;
      case G4P.NO:
      }
    }
  }
  catch (Exception e) {
    console.println(e+"");
  }
}

public void eval(String command) {
  try {
    if (command.startsWith("help")) {
      console.println("Key:");
      console.println("[] - Required");
      console.println("<> - Optional");
      console.println("----------------------------------------");
      console.println("help - shows this dialouge");
      console.println("noclip <boolean> - Toggles free movement, if a boolean is provided, will set value to boolean");
      console.println("debug <boolean> - Toggles the display of debug information, if a boolean is provided, will set value to boolean");
      console.println("setscore [integer]- Sets the score to a specified value");
    } else if (command.startsWith("noclip")) {
      String[] teb;
      teb=command.split(" ");
      if (teb.length>1) {
        noclip = teb[1].contains("true");
      } else {
        noclip=!noclip;
      }
      console.println("noclip : " + noclip);
    } else if (command.startsWith("setscore")) {
      try {
        String[] teb = command.split(" ");
        score = Long.parseLong(teb[1].substring(0, teb[1].length()-1));
        console.println("Score set to : "+score);
      }
      catch(Exception e) {
        console.println(e+"");
      }
    } else if (command.startsWith("debug")) {
      String[] teb;
      teb=command.split(" ");
      if (teb.length>1) {
        debug = teb[1].contains("true");
      } else {
        debug=!debug;
      }
      console.println("debug : " + debug);
    } else {
      console.println("Unknown Command : "+command.substring(0, command.length()-1)+", refer to \"help\" for a list of commands");
    }
  }
  catch (Exception e) {
    console.println(e+"");
  }
}
public void reset() {
  boolean end=false, start=false;
  float chancewalls=100,min=5,max=95;
  for (int i=0; i<level.length; i++) {
    for (int j=0; j<level[i].length; j++) {
      int rand = (int) random(11);
      float rand2=random(100);
      if (start&&rand==2) {
        rand=1;
      }
      switch(difficulty){
       case(1):
       min=5;
       max=95;
       break;
       case(2):
       min=3;
       max=97;
       break;
       case(3):
       min=1;
       max=99;
       break;
       case(4):
       min=0.5f;
       max=99.4f;
       break;
       case(5):
       min=0.1f;
       max=99.9f;
      }
      if (rand==2) {
        if (rand2>max) {
          start=true;
          sx=i*scale;
          sy=j*scale;
          x=sx;
          y=sy;
        } else {
          rand=1;
        }
      }
      if (end&&rand==3) {
        rand=1;
      }
      if (rand==3) {
        if (rand2<min) {
          end=true;
          ex=i*scale;
          ey=j*scale;
        } else {
          rand=1;
        }
      }
      if(random(100)<chancewalls){
      level[i][j] =rand;
      }else{
       if(rand==1){
        rand=0; 
       }
       level[i][j]=rand;
      }
      //println(rand);
    }
  }
  if(!start || !end){
   reset(); 
  }
}
class Console {
  int x=0;
  int y=0;
  int width=0;
  int height=0;
  ArrayList<String> console= new ArrayList();
  Console(int x, int y, int width, int height) {
    this.x=x;
    this.y=y;
    this.width=width;
    this.height=height;
  }

  public void println(String string) {
    console.add(string);
  }
  public void clear() {
    console=new ArrayList();
  }
  public void render() {
    fill(0, 150);
    stroke(0);
    rectMode(CORNER);
    rect(this.x, this.y, this.width, this.height);
    fill(255);
    stroke(255);
    textAlign(LEFT);
    textSize(10);
    for (int i=console.size(); i>0; i--) {
      text(console.get(constrain((int)map(i, 0, console.size(), console.size(), 0), 0, console.size())), 20, ((this.x+this.height)-(i*12))-25);
    }
    fill(51, 150);
    stroke(0);
    rect(0, this.y+this.height-12, this.width, 12);
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Blocky" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
