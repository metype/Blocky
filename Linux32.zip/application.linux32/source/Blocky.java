import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import g4p_controls.*; 
import java.awt.Font; 
import java.awt.GraphicsEnvironment; 
import java.awt.GraphicsDevice; 
import java.awt.HeadlessException; 
import java.awt.event.KeyEvent; 
import java.lang.reflect.Field; 
import java.awt.datatransfer.Clipboard; 
import java.awt.datatransfer.Transferable; 
import java.awt.datatransfer.DataFlavor; 
import java.awt.datatransfer.UnsupportedFlavorException; 
import java.awt.Toolkit; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Blocky extends PApplet {








Main main;
GButton Random;
GButton Controls;
GButton Start;
GButton Back;
GButton Difficulty;
GButton LevelWrap;
GButton Quit;
GButton Info;
GButton ScreenNum;
GButton Options;
GButton Cheats;
GButton Possible;
GButton ControlChange;
GButton ControlReset;
GButton RenderStatic;
GSlider2D FrameRate;
public void settings() {
  main = new Main();
  String[] teb= 
    main.settings[0].split("=");
  fullScreen(JAVA2D, Integer.parseInt(teb[1]));
  //size(1280,720);
}

public void setup() {
  frameRate(main.framerate);
  main.start();
  //txf = new GTextField(this, 10, 10, 280, 46);
  // txf.setFont(new Font("Dialog", Font.PLAIN, 24));
  // txf.setText("Random");
  FrameRate = new GSlider2D(this, (width/2)-150, 300, 300, 75);
  FrameRate.setLimitsY(0, 0);
  FrameRate.setLimitsX(0.05f, 2.4f);
  float fr = main.framerate;
  FrameRate.setValueX(fr/100);
  FrameRate.setVisible(false);
  Random=new GButton(this, width/2-150, 250, 300, 75, "Random");
  Random.setFont(new Font("Dialog", Font.PLAIN, 34));
  Controls=new GButton(this, width/2-150, 350, 300, 75, "Controls");
  Controls.setFont(new Font("Dialog", Font.PLAIN, 34));
  Info=new GButton(this, width/2-150, 450, 300, 75, "Information");
  Info.setFont(new Font("Dialog", Font.PLAIN, 34));
  Quit=new GButton(this, width/2-150, 650, 300, 75, "Quit");
  Quit.setFont(new Font("Dialog", Font.PLAIN, 34));
  ControlChange=new GButton(this, width/2-150, 480, 300, 45, "Change Controls");
  ControlChange.setFont(new Font("Dialog", Font.PLAIN, 34));
  ControlChange.setVisible(false);
  ControlReset=new GButton(this, width/2-150, 540, 300, 45, "Reset Controls");
  ControlReset.setFont(new Font("Dialog", Font.PLAIN, 34));
  ControlReset.setVisible(false);
  Back=new GButton(this, width/2-150, 600, 300, 75, "Back");
  Back.setFont(new Font("Dialog", Font.PLAIN, 34));
  Back.setVisible(false);
  Start=new GButton(this, width/2-150, 500, 300, 75, "Start");
  Start.setFont(new Font("Dialog", Font.PLAIN, 34));
  Start.setVisible(false);
  Difficulty=new GButton(this, width/2-300, 200, 250, 75, "Difficulty:1");
  Difficulty.setFont(new Font("Dialog", Font.PLAIN, 34));
  Difficulty.setVisible(false);
  LevelWrap=new GButton(this, width/2+50, 200, 250, 75, "Level Wrapping:true");
  LevelWrap.setFont(new Font("Dialog", Font.PLAIN, 30));
  LevelWrap.setVisible(false);
  main.settings = loadStrings("settings.txt");
  String[] teb = main.settings[0].split("=");
  ScreenNum=new GButton(this, width/2-150, 100, 300, 75, "Default Screen:"+teb[1]);
  ScreenNum.setFont(new Font("Dialog", Font.PLAIN, 34));
  ScreenNum.setVisible(false);
  Cheats=new GButton(this, width/2-150, 200, 300, 75, "Cheats:"+main.settings[1].split("=")[1]);
  Cheats.setFont(new Font("Dialog", Font.PLAIN, 34));
  Cheats.setVisible(false);
  RenderStatic=new GButton(this, width/2-150, 300, 300, 75, "Render Static:"+main.settings[2].split("=")[1]);
  RenderStatic.setFont(new Font("Dialog", Font.PLAIN, 34));
  RenderStatic.setVisible(false);
  main.allowCheats=Boolean.parseBoolean(main.settings[1].split("=")[1]);
  Options=new GButton(this, width/2-150, 550, 300, 75, "Options");
  Options.setFont(new Font("Dialog", Font.PLAIN, 34));
  Options.setVisible(true);
  main.console=new Console(0, 0, width, 500);
  surface.setTitle("Blocky - A Puzzle Game v"+main.version);
  surface.setIcon(loadImage("data/icon.png"));
}

public void draw() {
  main.update();
}

public void handleButtonEvents(GButton button, GEvent event) {
  try {
    if (button == Random) {
      main.mode=4;
    }
    if (button == Controls) {
      main.mode=2;
    }
    if (button==ControlChange) {
      main.controls=new PWindow(main);
    }
    if (button==ControlReset) {
      String[] controlScheme1=new String[8];
      controlScheme1[0]=main.defaultUpCode+"";
      controlScheme1[1]=main.defaultLeftCode+"";
      controlScheme1[2]=main.defaultDownCode+"";
      controlScheme1[3]=main.defaultRightCode+"";
      controlScheme1[4]=main.defaultExitCode+"";
      controlScheme1[5]=main.defaultResetCode+"";
      controlScheme1[6]=main.defaultPlayerResetCode+"";
      controlScheme1[7]=main.defaultConsoleCode+"";
      saveStrings("data/controls.txt", controlScheme1);
      main.controlScheme=loadStrings("data/controls.txt");
      if (main.controlScheme!=null) {
        if (main.controlScheme.length>7) {
          main.upCode=Integer.parseInt(main.controlScheme[0]); 
          main.leftCode=Integer.parseInt(main.controlScheme[1]); 
          main.downCode=Integer.parseInt(main.controlScheme[2]); 
          main.rightCode=Integer.parseInt(main.controlScheme[3]); 
          main.exitCode=Integer.parseInt(main.controlScheme[4]); 
          main.resetCode=Integer.parseInt(main.controlScheme[5]); 
          main.playerResetCode=Integer.parseInt(main.controlScheme[6]); 
          main.consoleCode=Integer.parseInt(main.controlScheme[7]);
        }
      }
    }
    if (button == Start) {
      main.mode=1;
      switch(main.difficulty) {
        case(1):
          main.scale=75;
        break;
        case(2):
        main.scale=60;
        break;
        case(3):
        main.scale=45;
        break;
        case(4):
        main.scale=35;
        break;
        case(5):
        main.scale=20;
      }
      main.level = new int[width/main.scale][height/main.scale];
      reset();
    }
    if (button==Quit&&main.mode==0) {
      exit();
    }
    if (button==Back) {
      if (main.versionS!=null) {
        if (Float.parseFloat(main.versionS[0])>main.version) {
          main.newVersionAvailable=true;
        }
      }
      main.mode=0;
    }
    if (button==Difficulty) {
      main.difficulty=(main.difficulty==5)?1:main.difficulty+1;
      Difficulty.setText("Difficulty:"+main.difficulty);
    }
    if (button==LevelWrap) {
      main.levelWrap=!main.levelWrap;
      LevelWrap.setText("Level Wrapping:"+main.levelWrap);
    }
    if (button==Info) {
      main.mode=3;
    }
    if (button==Options) {
      main.mode=5;
    }
    if (button==ScreenNum) {
      main.settings = loadStrings("settings.txt");
      String[] teb = main.settings[0].split("=");
      int val = Integer.parseInt(teb[1]);
      val=(val>=main.numberofScreens)?1:val+1;
      main.settings[0]="screen="+val;
      ScreenNum.setText("Default Screen:"+val);
      saveStrings("data/settings.txt", main.settings);
    }
    if (button==Cheats) {
      main.settings = loadStrings("settings.txt");
      String[] teb = main.settings[1].split("=");
      boolean val = Boolean.parseBoolean(teb[1]);
      val=!val;
      main.allowCheats=val;
      main.settings[1]="cheats="+val;
      Cheats.setText("Cheats:"+val);
      saveStrings("data/settings.txt", main.settings);
    }
    if (button==RenderStatic) {
      main.settings = loadStrings("settings.txt");
      String[] teb = main.settings[2].split("=");
      boolean val = Boolean.parseBoolean(teb[1]);
      val=!val;
      main.renderStatic=val;
      main.settings[2]="render_static="+val;
      RenderStatic.setText("Render Static:"+val);
      saveStrings("data/settings.txt", main.settings);
    }
  }
  catch (Exception e) {
    main.console.println(e+"");
  }
}

public void keyPressed() {
  main.keyHandler();
}

public void handleOptionDialog(int num) {
  try {
    if (num==1) {
      int reply = G4P.selectOption(this, "Are you sure you want to return to title screen?", "Warning", G4P.WARNING, G4P.YES_NO);
      switch(reply) {
      case G4P.OK:
        main.loadVersion=true;
        main.mode=0;
        break;
      case G4P.NO:
      }
    } else if (num==2) {
      int reply = G4P.selectOption(this, "Are you sure you want to quit the game?", "Warning", G4P.WARNING, G4P.YES_NO);
      switch(reply) {
      case G4P.OK: 
        exit();
        break;
      case G4P.NO:
      }
    }
  }
  catch (Exception e) {
    main.console.println(e+"");
  }
}


public void handleSlider2DEvents(GSlider2D slider2d, GEvent event) {
  if (slider2d == FrameRate) {
    main.framerate = floor(FrameRate.getValueXF()*100);
    main.settings[3]="framerate="+FrameRate.getValueXF()*100;
    frameRate(FrameRate.getValueXF()*100);
    saveStrings("data/settings.txt", main.settings);
  }
}

public void mousePressed() {
  main.mouseHandler();
}

  public void mouseWheel(MouseEvent event) {
main.wheelHandler(event);
  }
  
  public void keyReleased(){
   main.keyReleaseHandler(); 
  }






public String getTextFromClipboard (){
  String text = (String) getFromClipboard(DataFlavor.stringFlavor);
  return text;
}



public Object getFromClipboard (DataFlavor flavor) {

  Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard(); 
  Transferable contents = clipboard.getContents(null);
  Object object = null;

  if (contents != null && contents.isDataFlavorSupported(flavor))
  {
    try
    {
      object = contents.getTransferData(flavor);
   
    }

    catch (UnsupportedFlavorException e1) // Unlikely but we must catch it
    {
      //~  e1.printStackTrace();
    }

    catch (java.io.IOException e2)
    {
      //~  e2.printStackTrace();
    }
  }

  return object;
} 
class PWindow extends PApplet {
  Main main;
  PWindow(Main main) {
    super();
        this.main=main;
    PApplet.runSketch(new String[] {this.getClass().getSimpleName()}, this);
  }
  int index=0;
  public void settings() {
    size(400, 400);
  }

  public void setup() {
    background(51);
  }

  public void draw() {
    background(51);
    textAlign(LEFT);
    textSize(30);
    rect(0, (index*20)+(26*index)+22, 20, 20);
    text("Up:"+KeyEvent.getKeyText(main.upCode)+"\nLeft:"+KeyEvent.getKeyText(main.leftCode)+"\nDown:"+KeyEvent.getKeyText(main.downCode)+"\nRight:"+KeyEvent.getKeyText(main.rightCode)+"\nExit Screen:"+KeyEvent.getKeyText(main.exitCode)+"\nReset Map:"+KeyEvent.getKeyText(main.resetCode)+"\nReset Player Pos:"+KeyEvent.getKeyText(main.playerResetCode)+"\nConsole:"+KeyEvent.getKeyText(main.consoleCode), 40, 45);
  }

  public void keyPressed() {
    switch(index) {
      case(0):
      main.upCode=keyCode;
      break;
      case(1):
      main.leftCode=keyCode;
      break;
      case(2):
      main.downCode=keyCode;
      break;
      case(3):
      main.rightCode=keyCode;
      break;
      case(4):
      main.exitCode=keyCode;
      break;
      case(5):
      main.resetCode=keyCode;
      break;
      case(6):
      main.playerResetCode=keyCode;
      break;
      case(7):
      main.consoleCode=keyCode;
      key=' ';
      index=0;
      savecontrols();
      exit();
    }
    key=' ';
    index++;
  }
  public @Override void exit() {

    index=0;
    //super.exit();
  }
  public void savecontrols(){
    String[] controlscheme1=new String[8];
    controlscheme1[0]=main.upCode+"";
    controlscheme1[1]=main.leftCode+"";
    controlscheme1[2]=main.downCode+"";
    controlscheme1[3]=main.rightCode+"";
    controlscheme1[4]=main.exitCode+"";
    controlscheme1[5]=main.resetCode+"";
    controlscheme1[6]=main.playerResetCode+"";
    controlscheme1[7]=main.consoleCode+"";
    saveStrings("data/main.controls.txt",controlscheme1);
  }
}
public void reset() {
  main.dir=0;
  boolean end=false, start=false;
  float chancewalls=100, min=5, max=95;
  for (int i=0; i<main.level.length; i++) {
    for (int j=0; j<main.level[i].length; j++) {
      int rand = (int) random(11);
      float rand2=random(100);
      if (start&&rand==2) {
        rand=1;
      }
      switch(main.difficulty) {
        case(1):
        min=5;
        max=95;
        break;
        case(2):
        min=3;
        max=97;
        break;
        case(3):
        min=1;
        max=99;
        break;
        case(4):
        min=0.5f;
        max=99.4f;
        break;
        case(5):
        min=0.1f;
        max=99.9f;
      }
      if (rand==2) {
        if (rand2>max) {
          start=true;
          main.sx=i*main.scale;
          main.sy=j*main.scale;
          main.x=main.sx;
          main.y=main.sy;
        } else {
          rand=1;
        }
      }
      if (end&&rand==3) {
        rand=1;
      }
      if (rand==3) {
        if (rand2<min) {
          end=true;
          main.ex=i*main.scale;
          main.ey=j*main.scale;
        } else {
          rand=1;
        }
      }
      if (random(100)<chancewalls) {
        main.level[i][j] =rand;
      } else {
        if (rand==1) {
          rand=0;
        }
        main.level[i][j]=rand;
      }
      //println(rand);
    }
  }
  if (!start || !end) {
    reset();
  }
}
class Console {
  int x=0;
  int y=0;
  int width=0;
  int height=0;
  ArrayList<String> console= new ArrayList();
  ArrayList<String> colors= new ArrayList();
  Console(int x, int y, int width, int height) {
    this.x=x;
    this.y=y;
    this.width=width;
    this.height=height;
  }

  public void println(String string) {
    console.add(string);
    main.Coffy=0;
  }
    public void println(String string,int c) {
    console.add(string +"COLORHERE"+c);
    main.Coffy=0;
  }
    public void println(Exception string) {
    console.add(string+"");
    main.Coffy=0;
  }
    public void println(Exception string,int c) {
    console.add(string +"COLORHERE"+c);
    main.Coffy=0;
  }
    public void println(float string) {
    console.add(string+"");
    main.Coffy=0;
  }
    public void println(float string,int c) {
    console.add(string +"COLORHERE"+c);
    main.Coffy=0;
  }
    public void println(Boolean string) {
    console.add(string+"");
    main.Coffy=0;
  }
    public void println(Boolean string,int c) {
    console.add(string +"COLORHERE"+c);
    main.Coffy=0;
  }
    public void println(Object string) {
    console.add(string+"");
    main.Coffy=0;
  }
    public void println(Object string,int c) {
    console.add(string +"COLORHERE"+c);
    main.Coffy=0;
  }
  public void clear() {
    console=new ArrayList();
  }
  public void render() {
    try{
    fill(0, 150);
    stroke(0);
    rectMode(CORNER);
    rect(this.x, this.y, this.width, this.height);
    fill(255);
    stroke(255);
    textAlign(LEFT);
    textSize(main.consoleTextSize);
    for (int i=console.size(); i>0; i--) {
      if (i==console.size()&& (((this.x+this.height)-(i*main.consoleTextSize+2))-25)+main.Coffy>main.consoleTextSize) {
        main.Coffy-=((((this.x+this.height)-(i*main.consoleTextSize+2))-25)+main.Coffy)-main.consoleTextSize;
      }
      if ( (((this.x+this.height)-(i*main.consoleTextSize+2))-25)+main.Coffy<500-main.consoleTextSize-5) {
        if(console.get(constrain((int)map(i, 0, console.size(), console.size(), 0), 0, console.size())).contains("COLORHERE")){
          fill(Integer.parseInt(console.get(constrain((int)map(i, 0, console.size(), console.size(), 0), 0, console.size())).split("COLORHERE")[1]));
        }else {
         fill(255); 
        }
        text(console.get(constrain((int)map(i, 0, console.size(), console.size(), 0), 0, console.size())).split("COLORHERE")[0], 20, (((this.x+this.height)-(i*main.consoleTextSize+2))-25)+main.Coffy);
      }
    }
    fill(51, 150);
    stroke(0);
    rect(0, this.y+this.height-12, this.width, 12);
  }catch(Exception e){
   println(e+""); 
  }
}
}
class Main {
  Blocky thes;
  GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
  GraphicsDevice[] devices = env.getScreenDevices();
  public int numberofScreens = devices.length;
  String[] versionS;
  Console console;
  public int mode = 0;
  PImage icon;
  String[] controlScheme;
  PWindow controls=new PWindow(this);
  public float version = 1.3f;
  int[][] level;
  public String command = "";
  public int scale=45, sx=0, sy=0, x, y, ex, ey, difficulty=1, commandsIndex=0;
  public int dir=0;
  public boolean levelWrap=true;
  public int score=0;
  public boolean consoleShown=false;
  public boolean noclip=false, debug=false, allowCheats=false;
  ArrayList<String> commandslist = new ArrayList();
  public int tenmousex;
  public int tenmousey;
  String[] settings;
  public boolean newVersionAvailable=false;
  public int consoleCode=192, exitCode=27, playerResetCode=69, resetCode=82, upCode=87, leftCode=65, rightCode=68, downCode=83;
  public int defaultConsoleCode=192, defaultExitCode=27, defaultPlayerResetCode=69, defaultResetCode=82, defaultUpCode=87, defaultLeftCode=65, defaultRightCode=68, defaultDownCode=83;
  public boolean changeControls=false;
  public boolean renderStatic=true;
  public int highscore=0;
  public boolean loadVersion=false, actuallyLoad=false;
  public String link = "https://metype.github.io/Blocky/index.html";
  public int framerate;
  public int Coffy;
  public int consoleTextSize=15;
  public boolean ctrl;
  public int consoleScrollSpeed=15;
  Main() {
    controls.noLoop();
    controls.getSurface().setVisible(false);
    controlScheme=loadStrings("data/controls.txt");
    if (controlScheme!=null) {
      if (controlScheme.length>7) {
        upCode=Integer.parseInt(controlScheme[0]); 
        leftCode=Integer.parseInt(controlScheme[1]); 
        downCode=Integer.parseInt(controlScheme[2]); 
        rightCode=Integer.parseInt(controlScheme[3]); 
        exitCode=Integer.parseInt(controlScheme[4]); 
        resetCode=Integer.parseInt(controlScheme[5]); 
        playerResetCode=Integer.parseInt(controlScheme[6]); 
        consoleCode=Integer.parseInt(controlScheme[7]);
      }
    } else {
      String[] controlScheme1=new String[8];
      controlScheme1[0]=upCode+"";
      controlScheme1[1]=leftCode+"";
      controlScheme1[2]=downCode+"";
      controlScheme1[3]=rightCode+"";
      controlScheme1[4]=exitCode+"";
      controlScheme1[5]=resetCode+"";
      controlScheme1[6]=playerResetCode+"";
      controlScheme1[7]=consoleCode+"";
      saveStrings("data/controls.txt", controlScheme1);
    }
    versionS = loadStrings("https://raw.githubusercontent.com/metype/Blocky/master/version.txt");
    settings = loadStrings("settings.txt");
    if (versionS!=null) {
      if (Float.parseFloat(versionS[0])>version) {
        newVersionAvailable=true;
      }
    }
    if (settings==null) {
      settings=new String[100];
      settings[0]="screen=1";
      settings[1]="cheats=false";
      settings[2]="highscore=0";
      saveStrings("data/settings.txt", settings);
    } else if (settings.length<10) {
      settings=new String[100];
      settings[0]="screen=1";
      settings[1]="cheats=false";
      settings[2]="highscore=0";
      settings[3]="framerate=60";
      saveStrings("data/settings.txt", settings);
    }
    framerate =(int)Float.parseFloat(settings[3].split("=")[1]);
    highscore = Integer.parseInt(settings[2].split("=")[1]);
    String[] teb = settings[0].split("=");
  }

  public void start() {
    level = new int[width/scale][height/scale];
  }

  public void update() {
    if (Coffy<0) {
      Coffy=0;
    }
    try {
      background(51);

      textAlign(CENTER, CENTER);
      textSize(30);
      if (!loadVersion) {
        switch(mode) {
          case(0):
          if (actuallyLoad) {
            String[] versionS = loadStrings("https://raw.githubusercontent.com/metype/Blocky/master/version.txt");
            if (versionS!=null) {
              if (Float.parseFloat(versionS[0])>version) {
                newVersionAvailable=true;
              }
            }
            actuallyLoad=false;
          }
          score=0;
          fill(255);
          textSize(34);
          text("Blocky - A Puzzle Game", width/2, 50);
          textSize(15);
          text("Version : "+version, width/2, 80);
          if (newVersionAvailable) {
            text("New Version Available (v"+versionS[0]+")!, get it at: \"", (width/2)-textWidth(link)/2, 110);
            if ((mouseX-(width/2))>-14&&(mouseX-(width/2))<312&&mouseY>107&&mouseY<120) {
              fill(229, 210, 32);
            }
            text(link, (width/2)+textWidth("New Version Available (v"+versionS[0]+")!, get it at: \"")/2, 110);
            fill(255);
            text("\"", ((width/2)+textWidth("New Version Available (v"+versionS[0]+")!, get it at:  \""+link)/2)+1, 110);
          }
          if ((mouseX-(width/2))>-14&&(mouseX-(width/2))<312&&mouseY>107&&mouseY<120&&newVersionAvailable) {
            cursor(HAND);
          } else if (!(mouseX>(width-25)-textWidth(link)&&mouseY>height-40&&mouseY<height-20&&mouseX<width-25)) {
            cursor(ARROW);
          }
          textAlign(RIGHT);
          fill(255);
          text("Website : \"", width-20-textWidth(link+"\""), height-20);
          if (mouseX>(width-25)-textWidth(link)&&mouseY>height-40&&mouseY<height-20&&mouseX<width-25) {
            cursor(HAND);
            fill(229, 210, 32);
          } else if (!((mouseX-(width/2))>-14&&(mouseX-(width/2))<312&&mouseY>107&&mouseY<120&&newVersionAvailable)) {
            cursor(ARROW);
          }
          text(link, width-25, height-20);
          fill(255);
          text("\"", width-20, height-20);
          Back.setVisible(false);
          Start.setVisible(false);
          Difficulty.setVisible(false);
          Controls.setVisible(true);
          Random.setVisible(true);
          LevelWrap.setVisible(false);
          Quit.setVisible(true);
          Info.setVisible(true);
          Options.setVisible(true);
          ScreenNum.setVisible(false);
          Cheats.setVisible(false);
          ControlChange.setVisible(false);
          ControlReset.setVisible(false);
          RenderStatic.setVisible(false);
          FrameRate.setVisible(false);
          break;
          case(5):
          textAlign(LEFT);
          textSize(20);
          text("Changing this will require a restart\n to take effect", width/2+160, 130);
          text("Framerate:"+framerate, width/2+160, 340);
          Back.setVisible(true);
          Start.setVisible(false);
          Difficulty.setVisible(false);
          Controls.setVisible(false);
          Random.setVisible(false);
          LevelWrap.setVisible(false);
          Quit.setVisible(false);
          Info.setVisible(false);
          Options.setVisible(false);
          ScreenNum.setVisible(true);
          Cheats.setVisible(true);
          ControlChange.setVisible(false);
          ControlReset.setVisible(false);
          RenderStatic.setVisible(false);
          FrameRate.setVisible(true);
          break;
          case(1):
          float xoff=(width-(level.length*scale))/2;
          float yoff=(height-(level[0].length*scale))/2;
          if (!consoleShown) {
            if (frameCount%25==0) {
              if (tenmousex==mouseX&&tenmousey==mouseY) {
                noCursor();
              } else {
                cursor();
              }
              tenmousex=mouseX;
              tenmousey=mouseY;
            }
            if (tenmousex!=mouseX||tenmousey!=mouseY||mousePressed) {
              cursor();
              if (mousePressed) {
                tenmousex=0;
                tenmousey=0;
              }
            }
          } else {
            cursor();
          }
          stroke(0);
          for (int i=0; i<level.length; i++) {
            for (int j=0; j<level[i].length; j++) {
              if (level[i][j]==1) {
                fill(0);
              }
              if (level[i][j]==0||level[i][j]>=4) {
                fill(51);
              }
              if (level[i][j]==2) {
                fill(0, 200, 0);
              }
              if (level[i][j]==3) {
                fill(200, 0, 0);
              }
              square((i*scale)+xoff, (j*scale)+yoff, scale);
            }
          }
          fill(0, 200, 0);
          stroke(0);
          if (!noclip) {
            switch(dir) {
              case(1):
              if (level[x/scale][constrain((y-1)/scale, 0, (height/scale)-1)]!=1) {
                y-=scale;
              } else {
                //y+=scale;
                dir=0;
              }
              if (level[x/scale][constrain((y-1)/scale, 0, (height/scale)-1)]!=1) {
              } else {
                //y+=scale;
                dir=0;
              }
              break;
              case(2):
              if (level[x/scale][constrain((y+1)/scale, 0, (height/scale)-1)]!=1) {
                y+=scale;
              } else {
                y-=scale;
                dir=0;
              }
              if (level[x/scale][constrain((y+1)/scale, 0, (height/scale)-1)]!=1) {
              } else {
                y-=scale;
                dir=0;
              }
              break;
              case(4):
              if (level[constrain((x+1)/scale, 0, (width/scale)-1)][constrain((y)/scale, 0, (height/scale)-1)]!=1) {
                x+=scale;
              } else {
                x-=scale;
                dir=0;
              }
              if (level[constrain((x+1)/scale, 0, (width/scale)-1)][constrain((y)/scale, 0, (height/scale)-1)]!=1) {
              } else {
                x-=scale;
                dir=0;
              }
              break;
              case(3):
              if (level[constrain((x-1)/scale, 0, (width/scale)-1)][constrain((y)/scale, 0, (height/scale)-1)]!=1) {
                x-=scale;
              } else {
                dir=0;
              }
              if (level[constrain((x-1)/scale, 0, (width/scale)-1)][constrain((y)/scale, 0, (height/scale)-1)]!=1) {
              } else {
                //y+=scale;
                dir=0;
              }
              break;
            }
            edges();
          } else {
            switch(dir) {
              case(1):
              y-=scale;
              dir=0;
              break;
              case(2):
              y+=scale;
              dir=0;
              break;
              case(3):
              x-=scale;
              dir=0;
              break;
              case(4):
              x+=scale;
              dir=0;
            }
          }
          x=(constrain((int)x/scale, 0, (width/scale)-1))*scale;
          y=(constrain((int)y/scale, 0, (height/scale)-1))*scale;
          x=constrain(x, 0, width);
          y=constrain(y, 0, height);
          square(constrain(x+4, 0, width)+xoff, constrain(y+4, 0, height)+yoff, scale-8);
          if (x==ex&&y==ey) {
            reset();
            score++;
            if (score>highscore) {
              highscore=score;
              settings[2]="highscore="+score;
              saveStrings("data/settings.txt", settings);
            }
            dir=0;
          }
          Difficulty.setVisible(false);
          Controls.setVisible(false);
          Random.setVisible(false);
          Start.setVisible(false);
          Back.setVisible(false);
          LevelWrap.setVisible(false);
          Quit.setVisible(false);
          Info.setVisible(false);
          ControlReset.setVisible(false);
          RenderStatic.setVisible(false);
          FrameRate.setVisible(false);
          fill(255);
          textSize(20);
          textAlign(LEFT);
          text("Score : " + score, 2, 20);
          text("Highscore : " + highscore, 2, 40);
          textAlign(RIGHT);
          if (debug) {
            fill(51, 200);
            stroke(0, 200);
            String temp="Blocky Vanilla v"+version+"\nDifficulty:"+difficulty+"\nX:"+x+"\nY:"+y+"\nStart X:"+sx+"\nStart Y:"+sy+"\nEnd X:"+ex+"\nEnd Y:"+ey+"\nCheats:"+allowCheats+"\nDefault Screen:"+settings[0].split("=")[1]+"\nFPS:"+floor(frameRate);
            rect(width-textWidth(temp)-15, -10, width, 345);
            fill(255);
            text(temp, width-10, 20);
            textAlign(LEFT);
          }
          break;
          case(2):
          cursor();
          textAlign(CENTER, TOP);
          text("Controls:\n\nUp:"+KeyEvent.getKeyText(upCode)+"\nLeft:"+KeyEvent.getKeyText(leftCode)+"\nDown:"+KeyEvent.getKeyText(downCode)+"\nRight:"+KeyEvent.getKeyText(rightCode)+"\nExit Screen:"+KeyEvent.getKeyText(exitCode)+"\nReset Map:"+KeyEvent.getKeyText(resetCode)+"\nReset Player Pos:"+KeyEvent.getKeyText(playerResetCode)+"\nConsole:"+KeyEvent.getKeyText(consoleCode), width/2, 30);
          Controls.setVisible(false);
          Random.setVisible(false);
          Back.setVisible(true);
          Difficulty.setVisible(false);
          LevelWrap.setVisible(false);
          Quit.setVisible(false);
          Info.setVisible(false);
          Options.setVisible(false);
          ControlChange.setVisible(true);
          ControlReset.setVisible(true);
          RenderStatic.setVisible(false);
          FrameRate.setVisible(false);
          break;
          case(3):
          cursor();
          text("Information:\n\n\nWhen it looks like the map is resetting multiple times per one reset,\n what's actually happening is that the map generated doesn't have a start, end, or both.\n══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════\nYou start at the green tile and finish at the red.You can move in any direction \nyou please, however you keep moving till stopped by a wall.\n══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════\n", width/2, (height/2)-100);
          Controls.setVisible(false);
          Random.setVisible(false);
          Back.setVisible(true);
          Difficulty.setVisible(false);
          LevelWrap.setVisible(false);
          Quit.setVisible(false);
          Info.setVisible(false);
          Options.setVisible(false);
          ControlChange.setVisible(false);
          ControlReset.setVisible(false);
          RenderStatic.setVisible(false);
          FrameRate.setVisible(false);
          break;
          case(4):
          cursor();
          Controls.setVisible(false);
          Random.setVisible(false);
          Start.setVisible(true);
          Back.setVisible(true);
          Difficulty.setVisible(true);
          LevelWrap.setVisible(true);
          Quit.setVisible(false);
          Info.setVisible(false);
          Options.setVisible(false);
          ControlChange.setVisible(false);
          ControlReset.setVisible(false);
          RenderStatic.setVisible(false);
          FrameRate.setVisible(false);
        }
        if (!allowCheats) {
          consoleShown=false;
        }
        if (consoleShown) {
          if (mode!=1) {
            consoleShown=false;
          } else {
            console.render();
            fill(255);
            stroke(255);
            textSize(10);
            if (frameCount%50<25) {
              text(">"+command+"|", 20, console.x+console.height-3);
            } else {
              text(">"+command, 20, console.x+console.height-3);
            }
          }
        }
      } else if (loadVersion) {
        cursor();
        float xoff=(width-(level.length*scale))/2;
        float yoff=(height-(level[0].length*scale))/2;
        stroke(0);
        for (int i=0; i<level.length; i++) {
          for (int j=0; j<level[i].length; j++) {
            if (level[i][j]==1) {
              fill(0);
            }
            if (level[i][j]==0||level[i][j]>=4) {
              fill(51);
            }
            if (level[i][j]==2) {
              fill(0, 200, 0);
            }
            if (level[i][j]==3) {
              fill(200, 0, 0);
            }
            square((i*scale)+xoff, (j*scale)+yoff, scale);
          }
        }
        fill(0, 200, 0);
        square(constrain(x+4, 0, width)+xoff, constrain(y+4, 0, height)+yoff, scale-8);
        fill(255);
        textSize(20);
        textAlign(LEFT);
        text("Score : " + score, 2, 20);
        text("Highscore : " + highscore, 2, 40);
        textAlign(RIGHT);
        fill(51, 200);
        rectMode(CORNER);
        rect(0, 0, width, height);
        fill(0);
        textAlign(CENTER, CENTER);
        textSize(45);
        text("Loading...", width/2, height/2);
        loadVersion=false;
        actuallyLoad=true;
      }
    }
    catch (Exception e) {
      console.println(e+"");
    }
  }

  public void keyHandler() {
    try {
      if (!changeControls) {
        if (!consoleShown) {
          if (keyCode==upCode) {
            if (dir==0) {
              dir=1;
            }
          }
          if (keyCode==leftCode) {
            if (dir==0) {
              dir=3;
            }
          }
          if (keyCode==downCode) {
            if (dir==0) {
              dir=2;
            }
          }
          if (keyCode==rightCode) {
            if (dir==0) {
              dir=4;
            }
          }
          if (keyCode==exitCode) {
            key=' ';
            if (mode==1) {
              handleOptionDialog(1);
            } else if (mode==0) {
              handleOptionDialog(2);
            } else {
              if (versionS!=null) {
                if (Float.parseFloat(versionS[0])>version) {
                  newVersionAvailable=true;
                }
              }
              mode=0;
            }
          }
          if (keyCode==consoleCode) {
            consoleShown=!consoleShown;
          }
          if (keyCode==playerResetCode) {
            x=sx;
            y=sy;
            dir=0;
          }
          if (keyCode==resetCode) {
            reset();
          }
        } else {
          if (keyCode==17) {
            ctrl=true;
          }
          if (key!=BACKSPACE&&key!='') {
            if (((keyCode>=65&&keyCode<=90) || (keyCode<=59&&keyCode>=44) || keyCode==32 || keyCode==222 || (keyCode>=91&&keyCode<=93)|| keyCode==45 || keyCode==61||keyCode==192)&&!ctrl) {
              command+=key;
            }
          } else {

            if (ctrl&&keyCode==BACKSPACE) {
              String[] teb = command.split(" ");
              command="";
              teb[teb.length-1]="";
              for (int i=0; i<teb.length; i++) {
                command+=teb[i]+" ";
              }
              command = command.substring(0, (command.length()-2>-1)?command.length()-2:0);
            } else {
              command = command.substring(0, (command.length()-1>-1)?command.length()-1:0);
            }
          }
          if (ctrl&&keyCode==86) {
            String original = getTextFromClipboard(); 
            String teb = original.replaceAll("\n", "");
            command+= teb;
          }
          switch(key) {
            case(ENTER):
            commandslist.add(command);
            console.println(">"+command, color(0xff1BE0C4));
            eval(command);
            command="";
            break;
          }
          if (keyCode==consoleCode) {
            consoleShown=!consoleShown;
            command="";
          }
          if (keyCode==exitCode) {
            consoleShown=!consoleShown;
            command="";
            key=' ';
          }
          switch(keyCode) {
            case(38)://up
            commandsIndex=(commandsIndex>0)?commandsIndex-1:0;
            command=commandslist.get(commandsIndex);
            break;
            case(40)://down
            commandsIndex=(commandsIndex<commandslist.size()-1)?commandsIndex+1:commandslist.size()-1;
            command=commandslist.get(commandsIndex);
            break;
          default:
            commandsIndex=commandslist.size();
          }
        }
      } else {
        //control scheme change code
      }
    }
    catch (Exception e) {
      console.println(e+"");
    }
  }

  public void keyReleaseHandler() {
    if (keyCode!=BACKSPACE&&keyCode!=86) {
      ctrl=false;
    }
  }

  public void edges() {
    try {
      if (levelWrap) {
        if (x>width-scale&&dir==4) {
          x=0;
          dir=4;
          if (level[0][y/scale]==1) {
            x=width;
            dir=0;
          }
        }
        if (x<0&&dir==3) {
          x=width;
          dir=3;
          if (level[level.length-1][y/scale]==1) {
            x=0;
            dir=0;
          }
        }
        if (y<0&&dir==1) {
          y=height;
          dir=1;
          if (level[x/scale][level[x/scale].length-1]==1) {
            y=0;
            dir=0;
          }
        }
        if (y>height-scale&&dir==2) {
          y=-scale;
          dir=2;
          if (level[x/scale][0]==1) {
            y=height;
            dir=0;
          }
        }
      } else {
        dir=(x<0||y<0||y>height||x>width)?0:dir;
        x=(x<0)?0:x; 
        x=(x>width)?width:x; 
        y=(y>height)?height:y; 
        y=(y<0)?0:y;
      }
    }
    catch (Exception e) {
      console.println(e+"");
    }
  }


  public void eval(String command) {
    try {
      if (command.equals("help")) {
        console.println("Key:");
        console.println("[] - Required");
        console.println("<> - Optional");
        console.println("| - Or / Varies depending on other arguments");
        console.println("----------------------------------------");
        console.println("help - shows this dialouge");
        console.println("noclip <boolean> - Toggles free movement, if a boolean is provided, will set value to boolean");
        console.println("debug <boolean> - Toggles the display of debug information, if a boolean is provided, will set value to boolean");
        console.println("set [string] [boolean|integer|float|string <field name>]- Sets the specified feild to a specified value");
        console.println("listFields - Lists all fields that can be changed by the \"set\" command");
        console.println("get [string] - Gets the value of the specified feild");
        console.println("println [string (muct be in quotes)] <hex value> - Prints specified string to console and, if provided, in the color associated with the hex value.");
      } else if (command.split(" ")[0].equals("noclip")) {
        String[] teb;
        teb=command.split(" ");
        if (teb.length>1) {
          //noclip = teb[1].contains("true");
          if (teb[1].equals("true")) {
            noclip=true;
          } else if (teb[1].equals("false")) {
            noclip=false;
          } else {
            throw(new Exception("Boolean value not provided"));
          }
        } else {
          noclip=!noclip;
        }
        console.println("noclip : " + noclip);
      } else if (command.split(" ")[0].equals("set")) {
        try {
          String[] teb=command.split(" ");
          if (teb.length>=3) {
            Class<?> c = main.getClass();
            boolean field2=false;
            Field[] teb2=c.getFields();
            for (int i=0; i<teb2.length; i++) {
              if ((teb2[i]+"").split("Main.")[1].equals(teb[2])) {
                field2=true;
              }
            }
            String val = c.getField(teb[1].substring(0, teb[1].length()))+"";
            if (field2) {
              c.getField(teb[1]).set(main, c.getField(teb[2]).get(main));
            } else {
              if (val.contains("Boolean")) {
                c.getField(teb[1]).set(main, Boolean.parseBoolean(teb[2]));
              }
              if (val.contains("Long")) {
                c.getField(teb[1]).set(main, Integer.parseInt(teb[2]));
              }
              if (val.contains("int")) {
                c.getField(teb[1]).set(main, Integer.parseInt(teb[2]));
              }
              if (val.contains("Float")) {
                c.getField(teb[1]).set(main, Float.parseFloat(teb[2]));
              }
              if (val.contains("String")) {
                c.getField(teb[1]).set(main, teb[2]);
              }
            }
            console.println(c.getField(teb[1].substring(0, teb[1].length()))+"="+c.getField(teb[1]).get(main));
          } else {
            console.println("Not enough arguments provided");
          }
        }
        catch(Exception e) {
          console.println(e+"", 100);
        }
      } else if (command.split(" ")[0].equals("get")) {
        String[] teb=command.split(" ");
        Class<?> c = main.getClass();
        console.println(c.getField(teb[1].substring(0, teb[1].length()))+"="+c.getField(teb[1]).get(main));
      } else if (command.split(" ")[0].equals("debug")) {
        String[] teb;
        teb=command.split(" ");
        if (teb.length>1) {
          //noclip = teb[1].contains("true");
          if (teb[1].equals("true")) {
            debug=true;
          } else if (teb[1].equals("false")) {
            debug=false;
          } else {
            throw(new Exception("Boolean value not provided"));
          }
        } else {
          debug=!debug;
        }
        console.println("debug : " + debug);
      } else if (command.split(" ")[0].equals("listFields")) {
        Class<?> c = main.getClass();
        Field[] val = c.getFields();
        for (int i=0; i<val.length; i++) {
          console.println(val[i]+"");
        }
      } else if (command.split(" ")[0].equals("clear")) {
        console.clear();
      } else if (command.split(" ")[0].equals("println")) {
        String[] teb=command.split("\"");
        if (teb.length>=3) {
          console.println(teb[1], color(Integer.valueOf(teb[2].substring(1, 3), 16), Integer.valueOf(teb[2].substring(3, 5), 16), Integer.valueOf(teb[2].substring(5, 7), 16)));
        } else if (teb.length==2) {
          console.println(teb[1]);
        } else {
          console.println("Not enough arguments provided");
        }
      } else {
        console.println("Unknown Command : \""+(command.substring(0, command.length())).split (" ")[0]+"\", refer to \"help\" for a list of commands", color(200, 10, 5));
      }
    }
    catch (Exception e) {
      console.println(e, 100);
    }
  }

  public void mouseHandler() {
    if (controls!=null) {
      controls.exit();
    }
    if (mouseButton==LEFT) {
      if ((mouseX-(width/2))>-14&&(mouseX-(width/2))<312&&mouseY>107&&mouseY<120 && mode==0&&newVersionAvailable) {
        link(link);
      }
      if (mouseX>(width-25)-textWidth(link)&&mouseY>height-40&&mouseY<height-20&&mouseX<width-25) {
        link(link);
      }
    }
  }

  public void wheelHandler(MouseEvent event) {
    if (mouseY<500 && consoleShown) {
      float e = event.getCount();
      Coffy-=e*consoleScrollSpeed;
    }
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Blocky" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
